# AI Reality Scanner 📸

مشروع جاهز للرفع على GitHub وStreamlit Community Cloud.

## تشغيل محلي
```bash
pip install -r requirements.txt
streamlit run app.py
```

## تشغيل AI Vision
أضف `OPENAI_API_KEY` كـ Secret في Streamlit Cloud أو كمتغير بيئة محليًا.

> لا يمكن لأي تطبيق يستخدم نموذج رؤية سحابي أن يعمل بتحليل AI حقيقي بدون وسيلة وصول للنموذج (API key أو نموذج محلي). المشروع يحتوي على وضع عرض احتياطي حتى لا يتعطل التطبيق عند غياب المفتاح.

## Streamlit Cloud
- Main file: `app.py`
- Python dependencies: `requirements.txt`
- Secrets: `OPENAI_API_KEY`

## المزايا
- واجهة عربية حديثة ومتجاوبة.
- رفع JPG/PNG/WEBP.
- تصحيح اتجاه الصور تلقائيًا.
- تحليل تلقائي للمستندات والفواتير والأسئلة والكود والرسوم البيانية والصور العامة.
- رسائل خطأ واضحة.
- لا يحتوي على API key داخل الكود.
